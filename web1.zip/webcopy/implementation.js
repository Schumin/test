(function( $ ) {
	$.Shop = function( element ) {
		this.$element = $( element );
		this.init();
	};
	
	$.Shop.prototype = {
		init: function() {
		
		    // Properties
			// Object containing patterns for form validation
			this.requiredFields = {
				expression: {
					value: /^([\w-\.]+)@((?:[\w]+\.)+)([a-z]){2,4}$/
				},
				
				str: {
					value: ""
				}
				
			};
			
			// Method invocation
            
            this.initCheckout();

			this.handleAddToCartForm();
					
			
        },
        
        _initCheckout: function(){
            try {
                
                const paymentMethodsResponse = await callServer("https://checkout-test.adyen.com/v68/paymentMethods",{});
                const config = {
                    paymentMethodsResponse,
                    clientKey: '10001|C86A365E060CA71A03224C27CBE06E8F220C0C695064AAEFE3838661494DBCB21290D534438ED750E62EFD76FB68A35948C94F26AB64D013D9B4BE397EC046DCF3364EEE3C050193D5310D90F4304C11843D29BD607A2AFB1233FA1014DACF85C8D93EE6E12BD2C6D2FC23D719BE09AD86EAC5FA2D26192652A1233924A277414D07542264DBD07E1DE539F473AF928028461154BAF7E86041CF36CE634D034B4908AF38305E077DB6A62D802E5FE73959568DA19E410803E8B14E12264AFAC6F608E8E27DB5468F5CA84A586A3F06DE4050879CE93696477A2C5C791628D96CCFC93CB164621CF1DFB0AE55F44CF487A3D221E92D3E2A807B3FA36B780E6CB9',
                    locale: 'en-US',
                    environment: 'test',
                    showPayButton: true,
                    paymentMethodsConfiguration: {
        
                        card: {
                    
                          hasHolderName: true,
                          holderNameRequired: true,
                          billingAddressRequired: true,
                          amount: {
                              value:1000,
                              currency: 'EUR',
                          },
                        }
                    
                      }
                }
        
                const checkout = new AdyenCheckout(config);
                checkout.create("dropin").mount(document.getElementById(elementId,"dropin"))
            } catch (error) {
        
                console.error(error);
                alert("Error Occured!!");
                
            }
        
        
        
        },
		_callServer: function (url, data) {
            const res = await fetch(url, {
                method: 'POST',
                body: data ? JSON.stringify(data) :'',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
        
            return await res.json();
        }

	};
	
	$(function() {
		var shop = new $.Shop( "#site" );
	});

})( jQuery );


